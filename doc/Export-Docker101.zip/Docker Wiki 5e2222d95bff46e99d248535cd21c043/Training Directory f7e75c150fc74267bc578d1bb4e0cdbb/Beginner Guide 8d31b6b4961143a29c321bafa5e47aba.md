# Beginner Guide

Created: Jun 24, 2021 8:35 PM

[Getting started with Docker and Kubernetes: a beginners guide](https://www.educative.io/blog/docker-kubernetes-beginners-guide)

[https://www.educative.io/cdn-cgi/image/f=auto,fit=contain,w=1200/api/page/4679616276987904/image/download/4833294770241536](https://www.educative.io/cdn-cgi/image/f=auto,fit=contain,w=1200/api/page/4679616276987904/image/download/4833294770241536)