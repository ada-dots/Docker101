# Microsoft Documentation

Created: Jun 21, 2021 10:13 PM

[Introduction to Containers and Docker](https://docs.microsoft.com/en-us/dotnet/architecture/microservices/container-docker-introduction/)

![https://docs.microsoft.com/en-us/dotnet/architecture/microservices/container-docker-introduction/media/index/multiple-containers-single-host.png](https://docs.microsoft.com/en-us/dotnet/architecture/microservices/container-docker-introduction/media/index/multiple-containers-single-host.png)